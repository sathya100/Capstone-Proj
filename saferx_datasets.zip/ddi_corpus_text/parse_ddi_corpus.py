"""
Flattens the SemEval-2013 DDI Corpus XML files into a single CSV:
drug1, drug2, ddi (true/false), interaction_type, sentence, source_file, split, source_type

interaction_type is one of: mechanism, effect, advise, int, (blank if ddi=false)
"""
import csv
import glob
import os
import xml.etree.ElementTree as ET

ROOT = "/home/claude/saferx_data/ddi_corpus_text/DDICorpus"
OUT = "/home/claude/saferx_data/ddi_corpus_text/ddi_corpus_flat.csv"

rows = []
for split in ["Train", "Test"]:
    split_root = os.path.join(ROOT, split)
    if not os.path.isdir(split_root):
        continue
    for xml_path in glob.glob(os.path.join(split_root, "**", "*.xml"), recursive=True):
        # source type = DrugBank or MedLine, inferred from path
        source_type = "DrugBank" if "DrugBank" in xml_path else ("MedLine" if "MedLine" in xml_path else "Unknown")
        try:
            tree = ET.parse(xml_path)
        except ET.ParseError:
            continue
        root = tree.getroot()
        for sentence in root.findall("sentence"):
            text = sentence.get("text", "")
            entities = {e.get("id"): e.get("text") for e in sentence.findall("entity")}
            pairs = sentence.findall("pair")
            if not pairs:
                continue
            for pair in pairs:
                e1 = entities.get(pair.get("e1"), "")
                e2 = entities.get(pair.get("e2"), "")
                ddi = pair.get("ddi", "false")
                itype = pair.get("type", "") if ddi == "true" else ""
                rows.append({
                    "drug1": e1,
                    "drug2": e2,
                    "ddi": ddi,
                    "interaction_type": itype,
                    "sentence": text,
                    "source_file": os.path.basename(xml_path),
                    "split": split,
                    "source_type": source_type,
                })

with open(OUT, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=[
        "drug1", "drug2", "ddi", "interaction_type", "sentence",
        "source_file", "split", "source_type"
    ])
    writer.writeheader()
    writer.writerows(rows)

print(f"Wrote {len(rows)} rows to {OUT}")
true_rows = [r for r in rows if r["ddi"] == "true"]
print(f"  of which {len(true_rows)} are labeled DDI pairs")
from collections import Counter
print(Counter(r["interaction_type"] for r in true_rows))
